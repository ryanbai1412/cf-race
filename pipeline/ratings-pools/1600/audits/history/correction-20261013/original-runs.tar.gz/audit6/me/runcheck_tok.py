import json,sys,re
from pathlib import Path
X=Path('/home/ubuntu/audit6/x/1600'); import hashlib,os
RUN=Path(os.environ.get('RUNDIR','/home/ubuntu/audit6/me/run'))
def nums(s): return re.findall(r'-?\d+(?:\.\d+)?|infinity',s)
out={}
for pid in sys.argv[1:]:
    e=json.load(open(X/f'evidence/{pid}.json')); names=[r['name'] for r in json.load(open(X/f'packages/{pid}/provenance.json'))['tests']['pairs']]
    out[pid]={}
    for s in e['submissions']+[dict(x,excluded=True) for x in e.get('excludedSubmissions',[])]:
        sid=str(s['submissionId']); f=RUN/f'{pid}-{sid}.json'
        if not f.exists(): print(pid,sid,'NOT RUN'); continue
        r=json.load(open(f))
        if 'tests' not in r:
            print(pid,sid,'EXCL-not-compiled' if s.get('excluded') else 'NOT-COMPILED'); continue
        mine={t['name'][:-3]:t for t in r['tests'] if not t['name'].startswith('s')}
        samp=[t for t in r['tests'] if t['name'].startswith('s')]
        ev={x['test']:x for x in s['runs']} if 'runs' in s else (({x['test']:x for x in s['result']['runs']}) if isinstance(s.get('result'),dict) else {})
        first=None; numwrong=0; fmtonly=0; ex=None; hm=0; vs={}
        for n in names:
            t=mine[n]; exp=(X/f'packages/{pid}/tests/{n}.out').read_text().split()
            v='TLE' if t['timeout'] else 'RE' if t['rc']!=0 else 'AC' if (t['tokSha']==hashlib.sha256(' '.join(exp).encode()).hexdigest() if 'tokSha' in t else t['out'].split()==exp) else 'WA'
            vs[v]=vs.get(v,0)+1
            if n in ev and ev[n]['outputHash']==t['sha'] and ev[n]['verdict']==v: hm+=1
            if v!='AC':
                first=first or n
                if v=='WA':
                    o=t['out'].split()
                    if t.get('outBytes',0)>=200 and len(exp)>1:
                        numwrong+=1; ex=ex or f'{n}: long output, token hash differs'; continue
                    try: ok=len(o)==len(exp) and all(a==b or (b!='infinity' and float(a)==int(b)) for a,b in zip(o,exp))
                    except: ok=False
                    # debug-tolerant: answer tokens appear as the trailing tokens
                    tail=nums(t['out'])[-len(exp):] if len(exp) else []
                    dbg= tail==exp or (len(tail)==len(exp) and all(a==b or (b!='infinity' and re.fullmatch(r'-?\d+(\.\d+)?',a) and float(a)==int(b)) for a,b in zip(tail,exp)))
                    if ok or dbg: fmtonly+=1
                    else:
                        numwrong+=1; ex=ex or f"{n}: {' '.join((X/f'packages/{pid}/tests/{n}.in').read_text().split())[:60]} -> {' '.join(o)[:50]}, expected {' '.join(exp)[:50]}"
        myv='AC' if first is None else ('TLE' if mine[first]['timeout'] else 'RE' if mine[first]['rc'] else 'WA')
        d={'myVerdict':myv,'myFirstFailed':first,'evidenceVerdict':s.get('verdict'),'evidenceFailedTest':s.get('failedTest'),'perTestEvidenceMatch':f'{hm}/{len(names)}' if ev else 'n/a',
           'verdictCounts':vs,'maxCpu':max(t['cpu'] for t in mine.values()),'samplesOK':all(t['rc']==0 and not t['timeout'] for t in samp),'compiled':r['compiled']}
        if s['expected']!='OK': d.update({'numericallyWrongTests':numwrong,'formatOrDebugOnlyWA':fmtonly,'counterexample':ex})
        out[pid][sid]=d
        good=s.get('excluded') or ((hm==len(names)) and myv==s['verdict'] and first==s.get('failedTest') and (s['expected']=='OK' or numwrong>0 or vs.get('TLE')))
        print(pid,sid,'EXCL' if s.get('excluded') else s['expected'],myv,first,s.get('failedTest'),d['perTestEvidenceMatch'],vs,'num',d.get('numericallyWrongTests'),'fmt',d.get('formatOrDebugOnlyWA'),'cpu',d['maxCpu'],'OK' if good else 'PROBLEM')
json.dump(out,open(os.environ.get('OUTPREFIX','runcheck-')+'-'.join(sys.argv[1:])+'.json','w'),indent=1)
