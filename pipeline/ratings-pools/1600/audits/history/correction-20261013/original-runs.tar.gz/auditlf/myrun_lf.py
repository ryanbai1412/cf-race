import json, subprocess, sys, tempfile, os, shutil, uuid
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
IMAGE = 'python@sha256:5887f265d8d44d8b4734d3658b21d668edf5aaf92e4945bc0c984afbfab105d3'
HARN = '/home/ubuntu/audit5/me/myharness_tok.py'
jobs = json.load(open(sys.argv[1]))
def run(job):
    B = Path(job['base']); pid, sid = job['key'].split('/'); sub = job['sub']
    row = json.load(open(B / f'state/{pid}/source-row.json'))
    kind = 'cpp' if 'C++' in sub['programmingLanguage'] else 'py'
    d = Path(tempfile.mkdtemp(prefix='aud-')); (d / 'tests').mkdir(); names = []
    for p in sorted((B / f'packages/{pid}/tests').glob('*.in')):
        (d / 'tests' / p.name).write_bytes(p.read_bytes().replace(b'\r\n', b'\n')); names.append(p.name)
    json.dump({'source': sub['source'], 'kind': kind, 'cpu': row['time_limit'], 'mem': int(row['memory_limit']), 'tests': names}, open(d / 'req.json', 'w'))
    os.chmod(d, 0o755)
    for f in d.rglob('*'): os.chmod(f, 0o755 if f.is_dir() else 0o644)
    cmd = ['docker', 'run', '--rm', '--pull=never', '--name', 'aud-' + uuid.uuid4().hex[:12], '--network=none', '--read-only', '--user=65534:65534', '--cap-drop=ALL',
           '--security-opt=no-new-privileges', '--pids-limit=32', '--cpus=1', '--memory=2560m', '--memory-swap=2560m',
           '--tmpfs=/w:rw,exec,nosuid,size=128m,mode=1777', '--tmpfs=/tmp:rw,nosuid,size=16m',
           '-v', f'{d}:/in:ro', '-v', f'{HARN}:/h.py:ro', '--env', 'HOME=/w', IMAGE, 'python3', '-I', '/h.py']
    p = subprocess.run(cmd, capture_output=True, timeout=3600, env={'PATH': '/usr/bin:/bin'})
    shutil.rmtree(d)
    r = json.loads(p.stdout); r['key'] = job['key']
    json.dump(r, open(f'/home/ubuntu/auditlf/run/{pid}-{sid}.json', 'w'))
    return job['key'], r['compiled']
with ThreadPoolExecutor(3) as ex:
    for k, c in ex.map(run, jobs): print(k, c, flush=True)
