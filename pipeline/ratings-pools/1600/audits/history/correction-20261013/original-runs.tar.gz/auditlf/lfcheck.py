import json,hashlib,re,sys
from pathlib import Path
jobs=json.load(open(sys.argv[1])); res={}
for j in jobs:
    pid,sid=j['key'].split('/'); f=Path(f'run/{pid}-{sid}.json')
    if not f.exists(): continue
    B=Path(j['base']); e=json.load(open(B/f'evidence/{pid}.json')); s=[x for x in e['submissions'] if str(x['submissionId'])==sid][0]
    r=json.load(open(f)); first=None; nw=0; fmt=0
    names=[x['name'] for x in json.load(open(B/f'packages/{pid}/provenance.json'))['tests']['pairs']]
    mine={t['name'][:-3]:t for t in r['tests']}
    for n in names:
        t=mine[n]; exp=(B/f'packages/{pid}/tests/{n}.out').read_text().split()
        ok=not t['timeout'] and t['rc']==0 and t['tokSha']==hashlib.sha256(' '.join(exp).encode()).hexdigest()
        if not ok:
            first=first or n
            if t['timeout'] or t['rc']: continue
            o=t['out'].split()
            if t['outBytes']<200:
                try: fm=len(o)==len(exp) and all(a==b or float(a)==int(b) for a,b in zip(o,exp))
                except: fm=False
                tail=re.findall(r'-?\d+|infinity',t['out'])[-len(exp):]
                if fm or tail==exp: fmt+=1
                else: nw+=1
            else: nw+=1
    firstV=None if first is None else ('TLE' if mine[first]['timeout'] else 'RE' if mine[first]['rc'] else 'WA')
    res[j['key']]={'lfFirstFail':first,'lfFirstVerdict':firstV,'evidenceFailed':s['failedTest'],'sameFirst':first==s['failedTest'],'lfNumericWrong':nw,'lfFmtOnly':fmt}
    print(j['key'],res[j['key']])
json.dump(res,open(sys.argv[1].replace('jobs','lfres'),'w'),indent=1)
