import json, subprocess, sys, tempfile, os, shutil, hashlib, uuid
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
IMAGE = 'python@sha256:5887f265d8d44d8b4734d3658b21d668edf5aaf92e4945bc0c984afbfab105d3'
B = Path('/home/ubuntu/audit7/x/1600')
up = json.load(open('/home/ubuntu/audit7/me/upstream-subs.json'))
def run(key):
    pid, sid = key.split('/')
    row = json.load(open(B / f'state/{pid}/source-row.json'))
    sub = up[key]
    kind = 'cpp' if 'C++' in sub['programmingLanguage'] else 'py'
    d = Path(tempfile.mkdtemp(prefix='aud-')); (d / 'tests').mkdir()
    names = []
    for p in sorted((B / f'packages/{pid}/tests').glob('*.in')):
        shutil.copy(p, d / 'tests' / p.name); names.append(p.name)
    for p in sorted((B / f'packages/{pid}/samples').glob('*.in')):
        shutil.copy(p, d / 'tests' / ('s' + p.name)); names.append('s' + p.name)
    json.dump({'source': sub['source'], 'kind': kind, 'cpu': row['time_limit'], 'mem': int(row['memory_limit']), 'tests': names}, open(d / 'req.json', 'w'))
    os.chmod(d, 0o755)
    for f in d.rglob('*'): os.chmod(f, 0o755 if f.is_dir() else 0o644)
    name = 'aud-' + uuid.uuid4().hex[:12]
    cmd = ['docker', 'run', '--rm', '--pull=never', '--name', name, '--network=none', '--read-only', '--user=65534:65534', '--cap-drop=ALL',
           '--security-opt=no-new-privileges', '--pids-limit=32', '--cpus=1', '--memory=2560m', '--memory-swap=2560m',
           '--tmpfs=/w:rw,exec,nosuid,size=128m,mode=1777', '--tmpfs=/tmp:rw,nosuid,size=16m',
           '-v', f'{d}:/in:ro', '-v', '/home/ubuntu/audit7/me/myharness_tok.py:/h.py:ro', '--env', 'HOME=/w', IMAGE, 'python3', '-I', '/h.py']
    p = subprocess.run(cmd, capture_output=True, timeout=3600, env={'PATH': '/usr/bin:/bin'})
    shutil.rmtree(d)
    if len(p.stdout) > 64 << 20: raise RuntimeError('too big')
    r = json.loads(p.stdout); r['key'] = key; r['stderr'] = p.stderr[-500:].decode(errors='replace')
    json.dump(r, open(f'/home/ubuntu/audit7/me/runtok/{pid}-{sid}.json', 'w'))
    return key, r['compiled']
with ThreadPoolExecutor(4) as ex:
    for k, c in ex.map(run, sys.argv[1:]): print(k, c, flush=True)
